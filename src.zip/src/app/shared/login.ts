export class Login {
    L_id:number;
    Username:string;
    Password:string;
    UserType:string;


}
