import { Jwtresponse } from './jwtresponse';

describe('Jwtresponse', () => {
  it('should create an instance', () => {
    expect(new Jwtresponse()).toBeTruthy();
  });
});
