export class User {
    UId:number;
    FirstName:string;
    LastName:string;
    Age:number;
    Gender:string;
    Address:string;
    PhoneNumber:number;
    LId:number;
}
