export class Jwtresponse {
        UserName:string;
        UserType:string;
        token:string;
    
}
