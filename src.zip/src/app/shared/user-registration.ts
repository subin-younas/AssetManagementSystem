export class UserRegistration {
    
}
