import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import {Login} from './login'

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private httpClient: HttpClient, private router: Router) { }

    //get a user
    getUserByNamePassword(user: Login): Observable<any> {
      console.log(user.Username);
      console.log(user.Password);
      return this.httpClient.get(environment.apiUrl + "/api/login/" + user.Username + "/" + user.Password);
  
    }
      //authorise return token with usertype and username
  public loginVerify(user: Login) {
    //calling webservice url and passing username and password
    console.log("Attempt authenticate and authorize::");
    console.log(user);
    return this.httpClient.get(environment.apiUrl + "/api/login/" + user.Username + '/' + user.Password);
  }
  //logout
  public logOut() {
    localStorage.removeItem('username');
    localStorage.removeItem('AccessRole');
    sessionStorage.removeItem('username');
    sessionStorage.removeItem('AccessRole');
    sessionStorage.removeItem('uName');
    sessionStorage.removeItem('idToken');
  }


}
