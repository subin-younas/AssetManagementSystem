import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  //create an instance of user
  formData: User = new User();
  user: User[];


  constructor(private httpclient: HttpClient) { }

  //insert user
  insertUser(user: User): Observable<any> {
    return this.httpclient.post(environment.apiUrl + "/api/User", user);
  }

  // delete user 
  deleteUser(id: number) {
    return this.httpclient.delete(environment.apiUrl + "/api/User" + id);
  }

    //update employee
updateUser(user:User):Observable<any>{
  return this.httpclient.put(environment.apiUrl+"/api/Employee",user);
    }

  //get all users 
  bindListUsers(){
    this.httpclient.get(environment.apiUrl+"/api/User")
    .toPromise().then(response=>
      this.user=response as User[])
  }

  //get user by id

  User(userId:number):Observable<any>
  {
    return this.httpclient.get(environment.apiUrl+"/api/User/GetUser?id="+userId);
  }


}
