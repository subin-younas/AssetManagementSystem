import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import {Login} from '../shared/login';
import {AuthService} from '../shared/auth.service';
import {Jwtresponse} from '../shared/jwtresponse'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup;
  isSubmitted=false;
  jwtResponse:any=new Jwtresponse()

  loginUser: Login = new Login();
  error = '';

  constructor(private router:Router,private formBuilder:FormBuilder,private authService:AuthService) { }

  ngOnInit(): void {
        //formGroup
        this.loginForm = this.formBuilder.group(
          {
            Username: ['', [Validators.required, Validators.minLength(4)]],
            Password: ['', [Validators.required]]
          }
        );
  }

    // get controls 
    get formControls() {
      return this.loginForm.controls;
    }
  

    //login verify
  loginCredentials()
  {
    //valid or invalid 
    this.isSubmitted = true;
    console.log(this.loginForm.value);
    //#region Valid

    //invalid
    if (this.loginForm.invalid) {
      return;
    }

    //valid
    if (this.loginForm.valid) {
      //calling a method  from Authservice --Authorization
      this.authService.loginVerify(this.loginForm.value)
        .subscribe(data => {
          console.log(data);
          // token with roleid and name 
          this.jwtResponse=data;

          // store in local or session storage 
          sessionStorage.setItem("idToken",this.jwtResponse.token);
          sessionStorage.setItem("uName",this.jwtResponse.UserName);

          //Check the role--based on the role redirect our application 
          if (this.jwtResponse.UserType === "Admin") {
            //logged in as admin
            console.log("Admin");
            //storing in local storaage
            localStorage.setItem("username", this.jwtResponse.UserName);
            localStorage.setItem("AccessRole", this.jwtResponse.UserType);
            this.router.navigateByUrl('/admin');
          }
          //manager
          else if (this.jwtResponse.UserType === "Manager") {
            console.log("Manager");
            //storing in local storaage
            localStorage.setItem("username", this.jwtResponse.UserName);
            localStorage.setItem("AccessRole",this.jwtResponse.UserType);
            this.router.navigateByUrl('/manager');
          }
          else {
            this.error = "Invalid Authorization"

          }
           
        },
          error => this.error = 'Invalid Username and Passsword');
    }

  }

  //#endregion


  }


