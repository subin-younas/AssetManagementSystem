import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { User } from '../shared/user';
import { UserService } from '../shared/user.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  userId: number;
  user: User = new User();

  constructor(public userService: UserService, private router: Router,
    private route: ActivatedRoute) { }

  ngOnInit(): void {


  }
  onSubmit(form: NgForm) {
    console.log(form.value);
    let addId = this.userService.formData.UId;

    //insert 
    if (addId == 0 || addId == null) {
      this.insertUser(form);
      this.router.navigateByUrl("/userhome");
    }
    else
    //update
    {
      this.updateUser(form);
    }


  }

  //insert 
  insertUser(form?: NgForm) {
    console.log("Inserting a record...");
    this.userService.insertUser(form.value).subscribe(
      (result) => {
        console.log(result);
        // this.resetForm(form);
        // this.toastrService.success("Employee Record has been Inserted",'EmpAppv2021');
      }

    );
    window.location.reload();
  }


  //update

  updateUser(form?: NgForm) {
    console.log("Updating a record...");
    this.userService.updateUser(form.value).subscribe(
      (result) => {
        console.log(result);
        // this.resetForm(form);
        // this.toastrService.success("Employee Record has been Updated", 'EmpAppv2021');
      }

    );

  window.location.reload();
  }






}
