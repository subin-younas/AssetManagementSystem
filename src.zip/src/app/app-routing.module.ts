import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import {AdminComponent} from './admin/admin.component'
import {ManagerComponent} from './manager/manager.component';
import {AuthGuard} from './shared/auth.guard';
import {UserComponent} from './user/user.component'
import { UserlistComponent } from './user/userlist/userlist.component';

const routes: Routes = [
  {path:'login',component:LoginComponent},
  {path:'user',component:UserComponent},
  {path:'userlist',component:UserlistComponent},
  {path:'admin',component:AdminComponent,canActivate:[AuthGuard],data:{role:"Admin"}},
  {path:'manager',component:ManagerComponent,canActivate:[AuthGuard],data:{role:"Manager"}},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
