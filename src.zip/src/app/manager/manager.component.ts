import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../shared/auth.service';

@Component({
  selector: 'app-manager',
  templateUrl: './manager.component.html',
  styleUrls: ['./manager.component.css']
})
export class ManagerComponent implements OnInit {
  loggedusername: string;

  constructor(private authService: AuthService, private router: Router) { }

  ngOnInit(): void {
    this.loggedusername = localStorage.getItem("username");
  }

  //calling logout method
  logOut() {
    this.authService.logOut();
    this.router.navigateByUrl('login');
  }

}
